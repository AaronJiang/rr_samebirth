<?php
/**
* Fetch Same birthday, and Generate photo
* By aaron, 2012-08-31
*/
header('P3P:CP="CAO PSA OUR"');
session_start();

require_once '../class/RenrenRestApiService.class.php';
require_once '../class/callApi.class.php';
$rrObj = new RenrenRestApiService;
$rrObj->setEncode("utf-8");
$session_key=$_SESSION["session_key"];
$filename=md5(mktime().$session_key);
$callApi=new CallApi($session_key,$rrObj);

//Get user info
$userinfo=$callApi->getUserInfo();
$userBirth=explode('-', $userinfo[0]['birthday']);

//Get friends info
$friendsList=$callApi->getFriends();
$uids=implode(',', $friendsList);
$friendsInfo=$callApi->getFriendsInfo($uids);

//Filiter same birthday
$sameBirthList=array();
foreach ($friendsInfo as $key=>$detail) 
{
	$friendBirth=explode('-', $detail['birthday']);
	if($friendBirth==$userBirth)
	{
		$sameBirthList['sameyear'][]=$detail; //same birthday and birthyear
	}
	elseif($friendBirth[1]==$userBirth[1] && $friendBirth[2]==$userBirth[2])
	{
		$sameBirthList['diffyear'][]=$detail; //same birthday, diff birthyear
	}	
}

if(!empty($sameBirthList))
{ 
	$bgImage="../image/bg.jpg";
	//$fontTitle="../font/WCL-03.ttf";
	$font="../font/font.TTF";
	$bg_image=imagecreatefromjpeg($bgImage);
	$p_image=array();

	//create title
	/*$title="与我生日相同的好友";
	$titleColor=imagecolorallocate($bg_image,0,0,0);
	imagettftext($bg_image,16,0,95,30,$titleColor,$fontTitle,$title);*/

	//create list
	$i=0;
	if(!empty($sameBirthList['sameyear']))
	{	
		foreach ($sameBirthList['sameyear'] as $key => $users) 
		{ 
			$y=90+($i*60);
			$detail=$users['name']." ".$users['birthday'];
			imagettftext($bg_image,14,0,125,$y,$titleColor,$font,$detail);
			$p_image[]=imagecreatefromjpeg($users['tinyurl']);	
			$i++;
		}
	}	 
	if(!empty($sameBirthList['diffyear']))
	{	
		foreach ($sameBirthList['diffyear'] as $key => $users) 
	 	{ 
	 		$y=90+($i*60);
	 		$detail=$users['name']." ".$users['birthday'];
	 		imagettftext($bg_image,14,0,125,$y,$titleColor,$font,$detail);
	 		$p_image[]=imagecreatefromjpeg($users['tinyurl']);
			$i++;	
		}
	} 

	$count=count($p_image);
	//max match result is 4
	if($count>4)
	{
		$count=4;
	}
	for($i=0;$i<$count;$i++)
	{
		$y=60+($i*60);
		imagecopy($bg_image,$p_image[$i],65,$y,0,0,50,50);
		imagedestroy($p_image[$i]);
	}	
	if(imagejpeg($bg_image,"../upload/".$filename.".jpg"))
	{
		echo "<img id='uploadimg' src='http://anykee.com/apps/birthdates/upload/".$filename.".jpg'>";
	}
	
}
else
{
   	echo "居然没有一个好友和你生日相同...";
}
?>	
