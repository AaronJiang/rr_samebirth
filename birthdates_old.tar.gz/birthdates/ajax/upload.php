<?php
/**
* Upload friends birthday photo
* By aaron, 2012-08-31
*/
header('P3P:CP="CAO PSA OUR"');
session_start();

require_once '../class/RenrenRestApiService.class.php';
require_once '../class/callApi.class.php';
$rrObj = new RenrenRestApiService;
$rrObj->setEncode("utf-8");
$session_key=$_SESSION["session_key"];
$callApi=new CallApi($session_key,$rrObj);

$img_src=$_POST["img_src"];
//$img_src="http://anykee.com/apps/birthdates/image/test.jpg";
$res=$callApi->uploadPhoto($img_src);
print_r($res);
?>	
