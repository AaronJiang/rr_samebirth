<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="dialog/jquery.js"></script>
<!--jquery start-->
<script type="text/javascript">
$(document).ready(function(){
	$("#message").click(function(){
		$("#process").html("<div class='loading'>加载中...<br><img src='http://anykee.com/apps/birthdates/image/loading2.gif'></div>");
		$.get('ajax/generate.php',function(data){
			if(data!='')
			{
				var upload="<div id='upload'>上传到相册</div>";
				$("#process").html(data+upload);
			}	
		})
	})
	$("#upload").live("click",function(){
		if($("#upload").html()!='')
		{
			$("#upload").html("上传中...");
			var img_src=$("#uploadimg").attr("src");
			$.post('ajax/upload.php',{img_src:img_src},function(data){
				alert('上传成功');
				$("#upload").html("上传到相册");
			})	
		}	
	})
});
</script>
<!--jquery end-->
</head>
<body>	
<div class="container">	
	<div id="process">
		<p>&nbsp;</p>
		<h1>你知道吗？</h1>
		<p>每个人的生日都有其特殊意义，而人生中能遇到据说生日相同的好友更是非常珍贵的事。
			如果你愿意去算的话，400人中有人和你生日相同的概率高达66%。不信你也来试试？
		</p>
		<p>&nbsp;</p>
		<div id="message">开始测试</div>
	</div>
</div>

</body>
</html>