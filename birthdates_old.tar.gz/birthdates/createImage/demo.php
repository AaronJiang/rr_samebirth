<?
$couponBgImage="./demo/couponbg.png";
$font="./demo/arial.ttf";
$pramaryImage="http://hdn.xnimg.cn/photos/hdn221/20120705/1150/tiny_lD0t_1b44000178e31375.jpg";
$isImage=FALSE;
if(!empty($pramaryImage))
{
	$isImage=TRUE;
	$pramaryImageInfo=getimagesize($pramaryImage);
	$pramary_w=$pramaryImageInfo[0];
	$pramary_h=$pramaryImageInfo[1];
	switch($pramaryImageInfo[2])
	{
		case 1:
			$p_image=imagecreatefromgif($pramaryImage);
			break;
		case 2:
			$p_image=imagecreatefromjpeg($pramaryImage);
			break;
		case 3:
			$p_image=imagecreatefrompng($pramaryImage);
			break;
		default:
			return 1;
	}

}
$isImage=FALSE;
	if(!empty($couponBgImage)&&file_exists($couponBgImage))
	{
		$isImage=TRUE;
		$couponBgImageInfo=getimagesize($couponBgImage);
		$couponBg_w=$couponBgImageInfo[0];
		$couponBg_h=$couponBgImageInfo[1];
		switch($couponBgImageInfo[2])
		{
			case 1:
				$bg_image=imagecreatefromgif($couponBgImage);
				break;
			case 2:
				$bg_image=imagecreatefromjpeg($couponBgImage);
				break;
			case 3:
				$bg_image=imagecreatefrompng($couponBgImage);
				break;
			default:
				return 1;
		}
	
	}

$title="Jiang";
$font_size=14;
$title_temp = imagettfbbox($font_size,0,$font,$title);
$title_w = $title_temp[2] - $title_temp[6]; 
$title_h = $title_temp[3] - $title_temp[7]; 
unset($title_temp); 	
$title_posX = 15; 
$title_posY = 30; 
$titleColor=imagecolorallocate($bg_image,0,0,0);
imagettftext($bg_image,$font_size,0,$title_posX,$title_posY,$titleColor,$font,$title);


imagecopy($bg_image,$p_image,65,50,0,0,50,50);
//imagedestroy($p_image);
imagepng($bg_image,"./demo/new.png");

imagecopy($bg_image,$p_image,65,120,0,0,50,50);
imagedestroy($p_image);
imagepng($bg_image,"./demo/new.png");

?>