<?php
$im = imagecreatetruecolor(10,10);
imagepng($im,'test.png',9); # works as expected
imagedestroy($im);
?>